var app = angular.module('myApp', ['ui.router']);
app.controller('DashboardCtrl', function($scope) {
			
});

app.factory('$localstorage', ['$window', function($window) {
  return {
    set: function(key, value) {
      $window.localStorage[key] = value;
    },
    get: function(key, defaultValue) {
      return $window.localStorage[key] || defaultValue;
    },
    setObject: function(key, value) {
      $window.localStorage[key] = JSON.stringify(value);
    },
    getObject: function(key) {
      return JSON.parse($window.localStorage[key] || '{}');
    }
  }
}]);
app.controller('ShopCtrl', function($scope, $http) {
	
	$scope.users = [];
		var path  = 'https://blooming-beach-6155.herokuapp.com';
		
        $scope.getUsers = function(){
			$http({
				method: 'GET',
				url: path + '/api/v2/shops'
			}).
			success(function (data) {
			  $scope.users = data;
			}).
			error(function (error) {
				alert(JSON.stringify(error));
			});
		};
		$scope.getUsers();
   
	
			
});
app.controller('CustomerCtrl', function($scope, $http) {
		$scope.users = [];
		var path  = 'https://blooming-beach-6155.herokuapp.com';
		
        $scope.getUsers = function(){
			$http({
				method: 'GET',
				url: path + '/api/v2/shops'
			}).
			success(function (data) {
			  $scope.users = data;
			}).
			error(function (error) {
				alert(JSON.stringify(error));
			});
		};
		$scope.getUsers();
});
app.controller('ProductCtrl', function($scope, $filter, $localstorage) {
	
	
	   // init
    $scope.sort = {       
                sortingOrder : 'id',
                reverse : false
            };
    
    $scope.gap = 2;
    
    $scope.filteredItems = [];
    $scope.groupedItems = [];
    $scope.itemsPerPage = 10;
    $scope.pagedItems = [];
    $scope.currentPage = 0;
	$scope.items = [];
	var saved_items = $localstorage.getObject("ITEMS");   
	if(saved_items.length !== undefined){
		$scope.items = saved_items;
	}
	$scope.item = {};
	$scope.save = function(){
		var saved_items = $localstorage.getObject("ITEMS");   
		if(saved_items.length !== undefined){
			$scope.items = saved_items;
		}
		if($scope.From.$valid){
			$scope.item.id = Math.floor(Math.random()*90000) + 10000;
			$scope.item.created = Date.now();
			$scope.items.push($scope.item);
			$localstorage.setObject("ITEMS", $scope.items);
			$scope.item = {};
			$scope.search();
			$('#add_product').modal('hide');
			
		}else{
			alert("Invalid Entry!!!");
		}	
	};
	$scope.delete = function(index){
		$scope.items.splice(index, 1)
		$localstorage.setObject("ITEMS", $scope.items);
		$scope.search();

	}
    var searchMatch = function (haystack, needle) {
        if (!needle) {
            return true;
        }
        return haystack.toLowerCase().indexOf(needle.toLowerCase()) !== -1;
    };

    // init the filtered items
    $scope.search = function () {
        $scope.filteredItems = $filter('filter')($scope.items, function (item) {
            for(var attr in item) {
                if (searchMatch(item[attr], $scope.query))
                    return true;
            }
            return false;
        });
        // take care of the sorting order
        if ($scope.sort.sortingOrder !== '') {
            $scope.filteredItems = $filter('orderBy')($scope.filteredItems, $scope.sort.sortingOrder, $scope.sort.reverse);
        }
        $scope.currentPage = 0;
        // now group by pages
        $scope.groupToPages();
    };
    
  
    // calculate page in place
    $scope.groupToPages = function () {
        $scope.pagedItems = [];
        
        for (var i = 0; i < $scope.filteredItems.length; i++) {
            if (i % $scope.itemsPerPage === 0) {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)] = [ $scope.filteredItems[i] ];
            } else {
                $scope.pagedItems[Math.floor(i / $scope.itemsPerPage)].push($scope.filteredItems[i]);
            }
        }
    };
    
    $scope.range = function (size,start, end) {
        var ret = [];        
        console.log(size,start, end);
                      
        if (size < end) {
            end = size;
            start = size-$scope.gap;
        }
        for (var i = start; i < end; i++) {
            ret.push(i);
        }        
         console.log(ret);        
        return ret;
    };
    
    $scope.prevPage = function () {
        if ($scope.currentPage > 0) {
            $scope.currentPage--;
        }
    };
    
    $scope.nextPage = function () {
        if ($scope.currentPage < $scope.pagedItems.length - 1) {
            $scope.currentPage++;
        }
    };
    
    $scope.setPage = function () {
        $scope.currentPage = this.n;
    };

    // functions have been describe process the data for display
    $scope.search();

			
});




