app.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider
    .state('dashboard', {
      url: '/dashboard',
      templateUrl: 'pages/dashboard.html',
      controller: 'DashboardCtrl'
    })
	.state('shops', {
      url: '/shops',
      templateUrl: 'pages/shops.html',
      controller: 'ShopCtrl'
    })
	.state('customers', {
      url: '/customers',
      templateUrl: 'pages/customers.html',
      controller: 'CustomerCtrl'
    })
	.state('products', {
      url: '/products',
      templateUrl: 'pages/products.html',
      controller: 'ProductCtrl'
    });

  $urlRouterProvider.otherwise('dashboard');
});
