var Validator = (function (d, $) {
	
	var regex = {
		numType		: "^[0-9]+$",
		idType		: "^[a-zA-Z0-9]+$",
		nameType	: "^[a-zA-Z'/\-]+ ?[a-zA-Z'/\-]*$",
		emailType	: "^[a-zA-Z0-9_.\-]+\@[a-zA-Z0-9_\-]+\\.[a-zA-Z0-9_\-]+$",
		addressType	: "^[a-zA-Z0-9/#\(\)'\" \-]+$",
		postalCodeCanType : "^[a-zA-Z0-9]{6,6}$",
		firstNameType : "^([a-zA-Z-]+[ ])*([a-zA-Z-])+$",// KPMG new Messages
		middleNameType : "^([A-Za-z]+[ ])*([A-Za-z])+$",// KPMG new Messages
		lastNameType : "^([A-Za-z-]+[ ])*([A-Za-z-])+$", // KPMG new Messages
		secondLastNameType	: "^[a-zA-Z'/\-]+ ?[a-zA-Z'/\-]*$",// KPMG new Messages
		destinationCityType : "^([a-zA-Z]+[ ])*([a-zA-Z])+$",// KPMG new Messages
		addressLine2Type : "^([A-Za-z0-9#-]+[ ])*([A-Za-z0-9#-])+$"// KPMG new Messages
	};
	
	var messages = {
		numType		: "Invalid data. Only numeric characters are allowed.",
		idType		: "Invalid data. Only numeric and alphabets characters are allowed.",
		nameType	: "Invalid data. Only alphabets, apostrophe ('), hyphen (-), slash (/) and a single space are allowed.",
		emailType	: "Invalid email.",
		addressType	: "Invalid data. Only alphabets, digits, slash (/), hash #, left/right parenthesis (), apostrophe ('), quote (\"), hyphen (-) and space are allowed.",
		postalCodeCanType : "Invalid postal code.Make sure there are:No spaces before the number, No special characters.",
		firstNameType : "Invalid First Name.No space before the name.No special Character other than a hyphen (-) are allowed.", // KPMG new Messages
		middleNameType : "Invalid Middle Name.No space before the name.No special Characters are allowed.",// KPMG new Messages
		lastNameType : "Invalid Last Name.No space before the name.No special Character other than a hyphen (-) are allowed.",// KPMG new Messages
		secondLastNameType : "Invalid Second Last Name.Only apostrophe ('), hyphen (-), slash (/) and a single space are allowed.",// KPMG new Messages
		destinationCityType : "Invalid City Name.Make sure there are:No spaces before the name, No special characters. ",// KPMG new Messages
		addressLine2Type : "Invalid Street Address.No space before the name.No special characters are allowed.", // KPMG new Messages
		
	};
	
	var _validateRegex = function(f, type) {
		var val = $(f).val().trim();
		
		if(val == "") {
			return;
		}
		
		var ex = new RegExp(regex[type]);
		if(_validateSpaces(f, messages[type])){
			return;
		}
		if (!ex.test(val)) {
			Errors.add(f.id, messages[type]);
		}
	};
	
	var _validateForm = function () {
    	var fields = $('form :input').filter("[class$='Type'],[class*='Type ']");
    	
		$.each( fields, function( index, field ) {
			var classList = field.className.split(/\s+/);
			$.each( classList, function( index, cl ) {
				if(cl.indexOf('Type', cl.length - 4) !== -1) { // ends with Type
    				if(regex[cl] != undefined) {
    					_validateRegex(field, cl);
    				} else {
        				var fn = window['_validate_' + cl];
        				if(fn != undefined) {
        					if($(field).val().trim() == "") {
        						return;
        					}
        					
        					fn(field);
        				}
    				}
				}
			});
		});
	};

    return {
        Validate: function () {
        	_validateForm();
        },
    
        ValidateAndDisplay: function () {
        	_validateForm();
    		
    		if(Errors.hasErrors()) {
    			Errors.display();
    			return false;
    		} else {
    			return true;
    		}
        },
    
        RealTime: function (id) {
        	$('#' + id + ' :input').filter("[class$='Type'],[class*='Type ']").on('keyup', function() {
        		var field = this;
        		var classList = field.className.split(/\s+/);
        		$.each( classList, function( index, cl ) {
        			if(cl.indexOf('Type', cl.length - 4) !== -1) { // ends with Type
        				if(regex[cl] != undefined) {
        					_validateRegex(field, cl);
        				} else {
            				var fn = window['_validate_' + cl];
            				if(fn != undefined) {
            					fn(field);
            				}
        				}
        			}
        		});
            	if(Errors.hasErrors()) {
            		Errors.display();
            	}
        	});
        },
        
        ValidateRequired: function () {
        	var reqFields = $('.REQ_field:input, .req_field:input').not(':disabled');
        	var enable = true;
        	
    		$.each( reqFields, function( index, field ) {
    			field = $(field);
    			if(field.is('input:text') && field.val().trim().length == 0) {
    				var id =field.attr('id');
    				enable = false;
    				return false; // break
    			} else if (field.is('select') && field.val().trim().length == 0) {
    				enable = false;
    				return false; // break
    			}
    		});
    		
    		return enable;
        },

        ValidateRequiredForSelector: function (selector) {
        	var thisSelector = selector + ' .REQ_field:input, ' + selector + ' .req_field:input';
        	var reqFields = $(thisSelector).not(':disabled');
        	var enable = true;
        	
    		$.each( reqFields, function( index, field ) {
    			field = $(field);
    			if(field.is('input:text') && field.val().trim().length == 0) {
    				var id =field.attr('id');
    				enable = false;
    				return false; // break
    			} else if (field.is('select') && field.val().trim().length == 0) {
    				enable = false;
    				return false; // break
    			}
    		});
    		
    		return enable;
        }
    };

})(document, jQuery);

//common validation functions for numeric digits with diffrent logic
//function for exactly n numeric digits or m numeric digits
function exactNorMNumeric(f, n, m, msg) {
var val = $(f).val();
var nDigitsRegex = new RegExp("^[0-9]{"+n+"}$");
var nDigits = nDigitsRegex.test(val);
var mDigitsRegex = new RegExp("^[0-9]{"+m+"}$");
var mDigits = mDigitsRegex.test(val);
var testCaseAccountNumber = nDigits || mDigits;
if (!testCaseAccountNumber) {
    Errors.add(f.id, msg);
}
};

//function for minimum n numeric digits and maximum of m numeric digits
function minAndmaxNumeric(f, min, max, msg) {
var val = $(f).val();
var regex = new RegExp("^[0-9]{"+min+","+max+"}$");
if (!regex.test(val)) {
      Errors.add(f.id, msg);
}
};

//function for minimum n alphanumeric digits and maximum of m alphanumeric digits
function minAndmaxAlphaNumeric(f, min, max, msg) {
var val = $(f).val();
var regex = new RegExp("^[0-9a-zA-Z]{"+min+","+max+"}$");
if (!regex.test(val)) {
      Errors.add(f.id, msg);
}
}; 


/// Country wise validations

//For Poland 
function _validate_accountNumberPOLType (f) {
       minAndmaxNumeric(f, "26", "26" , "Invalid Account Number.Must be exactly of 26 digits");
}

//For  Nigeria 
function _validate_accountNumberNGNType(f) {
    minAndmaxNumeric(f, "10", "10" , "Invalid Account Number. Must be exactly of 10 numeric digits.");
};

//For France:
function _validate_ibanType(f){
     minAndmaxAlphaNumeric(f, "27", "27" , "Invalid IBAN. Must be exactly of 27 alphanumeric characters.");
} 
function _validate_bicType(f){
     minAndmaxAlphaNumeric(f, "8", "8" , "Invalid Data. Must be exactly of 8 alphanumeric characters.");
} 
function _validate_bankNameType(f){
     minAndmaxAlphaNumeric(f, "0", "20" , "Invalid Bank Name. Must be maximum of 20 alphanumeric characters.");
} 

//   For Kenya: 
function _validate_mpesaMobileNumberType(f){
     minAndmaxNumeric(f, "9", "9" , "Invalid MPESA Mobile Number. Must be exactly of 9 numeric digits");
}

//For China: 
function _validate_unionPayCardNumberType(f){
     minAndmaxNumeric(f, "16", "16" , "Invalid UnionPay Card Number. Must be exactly of 16 numeric digits");
}

//BANCOMER � Account Number is exactly ten (10) or twelve (12) numeric digits
function _validate_accountNumberBANCOMERmaxType(f) {
     exactNorMNumeric(f, "10", "12" , "Invalid Account Number. Must be exactly 10 numeric or exactly 12 numeric digits allowed");
};

function _validate_dayType (f) {
	var val = $(f).val().trim();
	var numRegex = new RegExp("^\\d*$");
	var day = parseInt(val, 10);
	if (!numRegex.test(val) || day < 1 || day > 31) {
		Errors.add(f.id, "Invalid day. Only 1 to 31 are allowed.");
	}
};

function _validate_monthType (f) {
	var val = $(f).val().trim();
	var numRegex = new RegExp("^\\d*$");
	var month = parseInt(val, 10);
	if (!numRegex.test(val) || month < 1 || month > 12) {
		Errors.add(f.id, "Invalid month. Only 1 to 12 are allowed.");
	}
};

function _validate_yearType (f) {
	var val = $(f).val().trim();
	var numRegex = new RegExp("^\\d*$");
	var year = parseInt(val, 10);
	if (!numRegex.test(val) || year < 1900 || year > 2099) {
		Errors.add(f.id, "Invalid year. Only 1900 to 2099 are allowed.");
	}
};

function _validate_dobYearType (f) {
	var val = $(f).val().trim();
	var numRegex = new RegExp("^\\d*$");
	var legalYear = new Date().getFullYear() - 18;
	var year = parseInt(val, 10);

	if (!numRegex.test(val) || year < 1900 || year > legalYear) {
		Errors.add(f.id, "Invalid year. Only 1900 to " + legalYear + " are allowed.");
	}
};

function _validate_phoneNumType (f) {
	var val = $(f).val().trim();
	var numRegex = new RegExp("^\\d*$");
	var repeatRegex = new RegExp("^(\\d)\\1*$");
	if(_validateSpaces(f, "Invalid phone number. Requirements for a phone number are: No hyphens, No spaces before the number,Must be a 10 digit number, " +
			"Must not be sequential,Must not begin with one(1) or zero(0), Fourth digit is not a one(1) or zero(0) ")){
		return;
	}
	if (!numRegex.test(val) || val.length < 5 || val.length > 14 || repeatRegex.test(val)) {
		Errors.add(f.id, "Invalid phone number. Must be between 5 and 14 digits. Can't be the same repeating digit.");
	}
};

function _validate_phoneNum2Type (f) { // allows all 9s
	var val = $(f).val().trim();
	var numRegex = new RegExp("^\\d*$");
	var repeatRegex = new RegExp("^([0-8])\\1*$");
	if(_validateSpaces(f, "Invalid phone number. Requirements for a phone number are: No hyphens, No spaces before the number,Must be a 10 digit number, " +
			"Must not be sequential,Must not begin with one(1) or zero(0), Fourth digit is not a one(1) or zero(0) ")){
		return;
	}
	if (!numRegex.test(val) || val.length < 5 || val.length > 14 || repeatRegex.test(val)) {
		Errors.add(f.id, "Invalid phone number. Must be between 5 and 14 digits. Can't be the same repeating digit.");
	}
};

function _validate_photoIdNumType (f) {
	var val = $(f).val().trim();
	val = val.replace(" ", ""); // remove spaces
	var idNumRegex = new RegExp("^[a-zA-Z0-9\-\\*]{4,}$");
	//	var numRegex = new RegExp("^\\d*$");
	var numRegex = new RegExp("^[\\d\\*]*$");
	var repeatHyphen = new RegExp("^(\-)\\1*$");
	var repeatDigits = new RegExp("^([0-8])\\1*$");
	var consecDigits = false;
	var consecPatAsc = "012345678901234567890123456789";
	var consecPatDesc = "987654321098765432109876543210";
	var allAsterisks = new RegExp("^(\\*)\\1*$");
	if(numRegex.test(val)) {
		consecDigits = (consecPatAsc.indexOf(val) >= 0 ) || (consecPatDesc.indexOf(val) >= 0 );
	} else {
		var val1 = val.substring(1);
		if(numRegex.test(val1)) {
			consecDigits = (consecPatAsc.indexOf(val1) >= 0 ) || (consecPatDesc.indexOf(val1) >= 0 );
		}
	}
	if(_validateSpaces(f, "Invalid photo ID number.")){
		return;
	}
	if (!idNumRegex.test(val) || repeatHyphen.test(val) || repeatDigits.test(val) || consecDigits || allAsterisks.test(val)) {
		Errors.add(f.id, "Invalid photo ID number.");
	}
};



function _validate_legalIdNumType (f) {
	var val = $(f).val().trim();
	val = val.replace(" ", ""); // remove spaces
	var idNumRegex = new RegExp("^[a-zA-Z0-9\-]{4,}$");
	var numRegex = new RegExp("^\\d*$");
	var repeatHyphen = new RegExp("^(\-)\\1*$");
	var repeatDigits = new RegExp("^([0-8])\\1*$");
	var consecDigits = false;
	var consecPatAsc = "012345678901234567890123456789";
	var consecPatDesc = "987654321098765432109876543210";
	
	var LegalIdType=$('#legalIdType').find('option:Selected').val();
	var IdType=$('#idType').find('option:Selected').val(); 
	
	if(LegalIdType=='TAX' || IdType=='TAX'){
		_validate_taxIdValueType(f);		
	}

	
	if(numRegex.test(val)) {
		consecDigits = (consecPatAsc.indexOf(val) >= 0 ) || (consecPatDesc.indexOf(val) >= 0 );
	} else {
		var val1 = val.substring(1);
		if(numRegex.test(val1)) {
			consecDigits = (consecPatAsc.indexOf(val1) >= 0 ) || (consecPatDesc.indexOf(val1) >= 0 );
		}
	}
	if(_validateSpaces(f, "Invalid legal ID number.")){
		return;
	}
	if (!idNumRegex.test(val) || repeatHyphen.test(val) || repeatDigits.test(val) || consecDigits) {
		Errors.add(f.id, "Invalid legal ID number.");
	}
};

function _validate_taxIdValueType (f) {
	var val = $(f).val().trim();
//	val = val.replace(" ", ""); // remove spaces
	var regex=new RegExp("^(?!666)^[0-9]{9}$");
	var repeatDigits = new RegExp("^([0-9])\\1*$");
	if(_validateSpaces(f, "Invalid Tax Id Value.")){
		return;
	}
	if(!regex.test(val) || repeatDigits.test(val)){
	    Errors.add(f.id, "Invalid Tax Id Value.");
	}	        
    
};


function _validate_phoneNumberType (f) {
	
	var val = $(f).val().trim();
//	val = val.replace(" ", ""); // remove spaces
	var regex=new RegExp("^(?!1)^(?!0)^[0-9]{10}$");
	var numRegex = new RegExp("^\\d*$");
    var consecDigits = false;
    var consecPatAsc = "012345678901234567890123456789";
    var consecPatDesc = "987654321098765432109876543210";
    if(numRegex.test(val)) {
    	consecDigits = (consecPatAsc.indexOf(val) >= 0 ) || (consecPatDesc.indexOf(val) >= 0 );
    } 
    else {
         var val1 = val.substring(1);
         if(numRegex.test(val1)) {
		      consecDigits = (consecPatAsc.indexOf(val1) >= 0 ) || (consecPatDesc.indexOf(val1) >= 0 );

		}
	}
	if(_validateSpaces(f, "Invalid phone number. Requirements for a phone number are: No hyphens, No spaces before the number,Must be a 10 digit number, " +
			"Must not be sequential,Must not begin with one(1) or zero(0), Fourth digit is not a one(1) or zero(0) ")){
		return;
	}
	if(!regex.test(val)  || consecDigits || val[3]=='0' || val[3]=='1'){                                    
		Errors.add(f.id, "Invalid phone number.Requirements for a phone number are: No hyphens, No spaces before the number,Must be a 10 digit number, Must not be sequential,Must not begin with one(1) or zero(0), Fourth digit is not a one(1) or zero(0)");                                                        
	}	        
};

function _validate_postalCodeUsaType (f){
	var country=$('#country').find('option:selected').val();
	var val = $(f).val().trim();
//	val = val.replace(" ", ""); // remove spaces
	if(_validateSpaces(f, "Invalid postal code. Make sure there are:No spaces before the number, No special characters, Zip code is a 5 digit number.")){
		return;
	}
	if(country=='USA' || country=='PRI'){
		var regex=new RegExp("^\\d{5}(\\d{4})?$");
		if(!regex.test(val)){
		    Errors.add(f.id, "Invalid postal code. Make sure there are:No spaces before the number, No special characters, Zip code is a 5 digit number.");
		}
	}
}

//KPMG Change Defect 233
function _validate_addressLine1Type (f){
	var val = $(f).val().trim();
//	val = val.replace(" ", ""); // remove spaces
	//var regex=new RegExp("^(?!PO)^(?!RR)^(?!P.O.)^(?!P. O.)^(?!R.R.)^(?!R. R.)^(?!Rural Route)^([a-zA-Z0-9#-]+[ ])*[a-zA-Z0-9#-]+$","i");
	var regex=new RegExp("^(?!PO)^(?!P.O.)^(?!P. O.)^([a-zA-Z0-9#-]+[ ])*[a-zA-Z0-9#-]+$","i");
	if(_validateSpaces(f, "Invalid Street Address.")){
		return;
	}
	if(!regex.test(val)){
	    Errors.add(f.id, "Invalid address potential PO Box or spaces");
	}
}

//KPMG Change Defect 233
function _validate_alternateNameType (f){
	var val = $(f).val().trim();
//	val = val.replace(" ", ""); // remove spaces
	var regex=new RegExp("^(?!AKA)^(?!DBA)^([a-zA-Z-]+[ ])*[a-zA-Z-]+$","i");
	if(_validateSpaces(f, "Invalid Alternate or Business Organisation Name.")){
		return;
	}
	if(!regex.test(val)){
	    Errors.add(f.id, "Invalid Alternate or Business Organisation Name.");
	}
}

//KPMG Change Defect 233
function _validate_occupationType (f){
	var val = $(f).val().trim();
//	val = val.replace(" ", ""); // remove spaces
	var regex=new RegExp("(?!AKA)^(?!DBA)^[a-zA-Z ]+?[a-zA-Z ]*$","i");
	if(_validateSpaces(f, "Invalid Occupation.")){
		return;
	}
	if(!regex.test(val)){
	    Errors.add(f.id, "Invalid Occupation.");
	}
}

//KPMG validation for ssn
function _validate_ssnType (f){
	var val = $(f).val().trim();
	var consecPatAsc = "012345678901234567890123456789";
	var consecPatDesc = "987654321098765432109876543210";
	if(consecPatAsc.indexOf(val) >= 0  || consecPatDesc.indexOf(val) >= 0 ){
		Errors.add(f.id, "Invalid SSN Id. Sequential Numbers are not allowed.");
	}
	
}

//KPMG validation Leading/Trailing spaces
function _validateSpaces(f,errorMessage){
	var valid = false;
	var val = $(f).val();
	var firstIndexVal = val.charAt(0);
	var lastIndexVal = val.charAt(val.length-1);
	if(firstIndexVal == ' '){
		valid = true;
		Errors.add(f.id, errorMessage+" No Leading spaces are allowed.");
	}
	return valid;
};

//sample
function _validate_xxxType (f) {
	var val = $(f).val().trim();
	var regex = new RegExp("^[a-zA-Z]+$");
	if(_validateSpaces(f, "Error numbers not allowed.")){
		return;
	}
	if (!regex.test(val)) {
		Errors.add(f.id, "Error numbers not allowed.");
	}
};

//Validating the account number for exactly twelve (12) numeric digits for BRA
function _validate_accountNumberBRAType(f){
	minAndmaxNumeric(f, "12", "12" , "Invalid Account Number. Must be of 12 digits.");
};

//Validating the bank code for exactly three (3) numeric digits for BRA
function _validate_bankCodeBRAType(f){
	minAndmaxNumeric(f, "3", "3" , "Invalid Receiver Bank Code. Must be of 3 digits.");
};

//Validating the branch code for exactly four (4) numeric digits for BRA
function _validate_branchCodeBRAType(f){
	minAndmaxNumeric(f, "4", "4" , "Invalid Receiver Branch Code. Must be of 4 digits.");
};

//Validating the CPF is maximum of twenty (20) characters for BRA
function _validate_cpfBRAType(f){
	minAndmaxAlphaNumeric(f, "0", "20" , "Invalid CPF. Must be of maximum 20 alphanumeric characters.");
};

//Validating the account number for maximum of twenty (20) numeric digits for PHL
function _validate_accountNumberPHLType(f){
	minAndmaxNumeric(f, "0", "20" , "Invalid Account Number. Must be of equal/less than 20 digits.");
};

//Validating the account number for is minimum of six (6) and a maximum of sixteen (16) numeric for LKA
function _validate_accountNumberLKAType(f) {
	minAndmaxNumeric(f, "6", "16" , "Invalid Account Number. Must be minimum of 6 digits and maximum of 16 digits.");
};

//Validating the Branch Name is maximum of twenty (20) alphanumeric characters for LKA
function _validate_branchNameLKAType(f) {
	minAndmaxAlphaNumeric(f, "0", "20" , "Invalid Branch Name. Must be of maximum 20 alphanumeric characters.");
};

//Validating the Account Number is minimum four (4) and at maximum eighteen (18) numeric for IND 
function _validate_accountNumberINDType(f) {
	minAndmaxNumeric(f, "4", "18" , "Invalid Account Number. Must be minimum of 4 digits and maximum of 18 digits.");
};

//Validating the IFSC Code is exactly 11 alphanumeric characters for IND
function _validate_ifscCodeINDType(f) {
	minAndmaxAlphaNumeric(f, "11", "11" , "Invalid IFSC CODE. Must be exactly of 11 alphanumeric characters.");
};

function _validate_accountNumberOCCIDENTEType(f) {
    minAndmaxNumeric(f, "4", "12" , "Invalid Account Number. Must be minimum of 4 digits and maximum of 12 digits.");
};

//  defect #378 FICOHSA - minimum of four (4) numeric and a maximum of nineteen (19) numeric digits

function _validate_accountNumberFICOHSAType(f) {
    minAndmaxNumeric(f, "4", "19" , "Invalid Account Number. Must be minimum of 4 digits and maximum of 19 digits.");
};

//  defect #378 CREDOMATIC -  exactly nine (9) numeric digits
function _validate_accountNumberCREDOMATICType(f) {
    minAndmaxNumeric(f, "9", "9" , "Invalid Account Number. Must be exactly of 9 digits.");
};

//  defect #378 ATLANTIDA - exactly ten (10) numeric or exactly twelve (12) numeric digits

function _validate_accountNumberATLANTIDAType(f) {
    exactNorMNumeric(f, "10", "12", "Invalid Account Number. Must be exactly 10 numeric or exactly 12 numeric digits allowed");
};

//defect #378 validating Account Number is exactly ten (10) numeric or twelve (12) numeric for SLV
function _validate_accountNumberSLVType(f) {
    exactNorMNumeric(f, "10", "12", "Invalid Account Number. Must be exactly 10 numeric or exactly 12 numeric digits allowed");
};

/// validation for Mexico, Account Number length depends on selected Delivery Option. For receiveAgentAbbreviation equals to

 

//DEBITCARDS � Account Number is exactly sixteen (16) numeric digits
function _validate_accountNumberDEBITCARDSmaxType(f) {
    minAndmaxNumeric(f, "16", "16" , "Invalid Account Number. Must be exactly of 16 digits.");
};

//OTHERBANKS - Account Number is exactly eighteen (18) numeric
function _validate_accountNumberOTHERBANKSmaxType(f) {
    minAndmaxNumeric(f, "18", "18" , "Invalid Account Number. Must be exactly of 18 digits.");
};
//BANCOMER � Account Number is exactly ten (10) or twelve (12) numeric digits
function _validate_accountNumberBANCOMERmaxType(f) {
    exactNorMNumeric(f, "10", "12" , "Invalid Account Number. Must be exactly 10 numeric or exactly 12 numeric digits allowed");
};
//BANORTE, SANTANDER, BANAMEX or SCOTIABANK - Account Number is eight (8) numeric and a maximum of eleven (11) numeric digits
function _validate_accountNumberOTHERSmaxType(f) {
    minAndmaxNumeric(f, "8", "11" , "Invalid Account Number. Must be minimum of 8 digits and maximum of 11 digits.");
};

