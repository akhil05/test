var RrnRegistration = (function(d, $) {
	function ajaxFormSubmit (url, successFn) {
		var form = $('form');
		$('input[type=text], input[type=textarea]').each(function() {
		    $(this).val($.trim($(this).val()).toUpperCase());
		});
		
		$.ajax({
			type: 'POST',
			url: url,
			data: form.serialize(),
			dataType: 'json',
			success: successFn,
			error: function () {
				Errors.addGlobal("globalErr_message", "Request failed.");
				Errors.display();			
			}
		});
	}
	var _handleRrnSuccess = function(resp) {
		// No errors
		if (resp.status.returncode == "0") {
			alert("Success");
		} else {
			Errors.addGlobal("globalErr_message", resp.status.returncode + ': ' + resp.status.message);
			Errors.display();
		}
	};

	var ValidateRequiredAndDisplay = function() {
		var reqFields = $('.REQ_field:input, .req_field:input').not(':disabled');	
		$.each(reqFields, function(index, field) {
			field = $(field);
			var id = field.attr('id');
			var label = $('#' + id + '_label').text();
			if (field.val().trim().length == 0) {
				Errors.add(id, label + " is required field.");
			}
		});
		if(Errors.hasErrors()) {
			Errors.display();
			return false;
		} else {
			return true;
		}
		
	};

	var _handleContinueClick = function(rrnRegistrationView) {
		Errors.clear();
		if (Validator.ValidateAndDisplay() && ValidateRequiredAndDisplay()) {
			ajaxFormSubmit(rrnRegistrationView, _handleRrnSuccess);
		}
	};



	return {
		Init : function(rrnRegistrationView) {

			//FormStyling.Init();

			$('#btnContinue').on("click", function(event) {
				//prevent full form submission
				event.preventDefault();
				_handleContinueClick(rrnRegistrationView);
			});

			
		}
	};

})(document, jQuery);