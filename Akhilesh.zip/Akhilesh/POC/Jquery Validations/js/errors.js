var Errors = (function (d, $) {
	var localErrors = [];
	var globalErrors = [];
	var showAlertBar = false;

	var _applyFieldErrors = function (errors) {
		if(errors == undefined) {
			return;
		}
		
		var obj = null,
			id = '',
			message = '';

		for (var i = 0; i < errors.length; i++) {
			id = errors[i].id;
			message = errors[i].message;
			obj = $('#' + id);

			//Verify we found the dom object
			if (obj.length > 0) {
				obj.addClass('validation-error');
				$('#' + id + "_label").addClass('validation-error-label');

			}
			_setupAlert(message);
		}
	};

	var _applyGlobalErrors = function () {
		for (var i = 0; i < globalErrors.length; i++) {
			var message = globalErrors[i].message;
			if(message.indexOf("(Int101)", message.length - 8) !== -1) {
				$('#globalErr_message2').text(message + " This transaction will be aborted and you will be redirected to the Home page.");
				openModal("#errorModal2");
			} else {
				_setupAlert(message);
			}
		}
	};

	var _setupAlert = function (message) {
		var bar = $('#globalErr_message_bar');
		if (bar.length > 0) {
			bar.append(message + "&nbsp;&nbsp;");
			showAlertBar = true;
		}
		var mdlMsg = $('#globalErr_message');
		//Verify we found the dom object
		if (mdlMsg.length > 0) {
			mdlMsg.append(message + "<br/>");
			mdlMsg.addClass('global-error');
		}
	};
	
	var _displayAlertBar = function () {
		var limit = 117;
		var ellipsis = "...";
		if ($('#globalErr_message_bar').text().length > limit) {
			var trimmedText = $('#globalErr_message_bar').text().substring(0, limit - 4);
			trimmedText += ellipsis;
			$('#globalErr_message_bar').text(trimmedText);
		}
		$('#errorAlert').show();
		$('#errorModalLaunch').bind('click', function () {
			openModalWithX('#errorModal');
		});
	};
	
	var _clear = function () {
		_clearLocal();
		_clearGlobal();
		_removeFromUI();
	};

	var _clearLocal = function () {
		localErrors = [];
	};

	var _clearGlobal = function () {
		globalErrors = [];
	};

	var _removeFromUI = function () {
		$('.validation-error').removeClass('validation-error');
		$('.validation-error-label').removeClass('validation-error-label');
		$('.error').removeClass('error');
		$('#globalErr_message').html('');
		$('#globalErr_message').removeClass('global-error');
		$('#errorAlert').hide();
		$('#globalErr_message_bar').html('');
		$('#errorModalLaunch').unbind('click');
		showAlertBar = false;
	};

	return {
		display: function (errors) {
			//closeModal();
			_applyFieldErrors(localErrors);
			_applyFieldErrors(errors);
			_applyGlobalErrors();
			if (showAlertBar) {
				_displayAlertBar();
			}
			_clearLocal();
		},
		
		displayWarning: function (errors) {
			$.modal.close();
			_applyFieldErrors(localErrors);
			_applyFieldErrors(errors);
			_applyGlobalErrors();
			if (showAlertBar) {
				$('#errorAlert').removeClass('banner').addClass('bannerWarn');
				_displayAlertBar();
			}
			_clearLocal();
		},
		
		add: function(id, message) {
			localErrors.push({
				'id': id,
				'message': message
			});
		},
		
		addGlobal: function(id, message) {
			globalErrors.push({
				'id': id,
				'message': message
			});
		},
		
		clear: function() {
			_clear();
		},
		
		hasErrors: function() {
			return (localErrors.length > 0 || globalErrors.length > 0);
		}
	};
	
})(document, jQuery);