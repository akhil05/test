$(document).ready(function () {

    // activate the tab using id.
    $('#responsiveTab').responsiveTab({
        breakpoint: 767,
        visibleTabIndex: 1,
        toggleTabMenu: '#toggle-tab'
    });
});


/// Custum function to create tab.
(function ($) {

    $.fn.responsiveTab = function (options) {

        // Establish our default settings
        var settings = $.extend({
            breakpoint: 767,
            visibleTabIndex: 1,
            toggleTabMenu: '#toggle-tab'
        }, options);

        return this.each(function () {
            var tabContainer = $(this),
                tabItem = $(this).children("ul").children("li"),
                tabContent = $(this).children(".tab-content"),
                tabReset = function () {
                    if ($(window).width() > parseInt(settings.breakpoint, 10)) {
                        $(settings.toggleTabMenu).hide();
                        tabItem.css('width', 'auto');
                        tabItem.children("a").css('display', 'inline-block');
                        tabItem.closest("ul").show();
                        tabItem.css('border-bottom', '0px solid #ccc');
                    } else {
                        $(settings.toggleTabMenu).show().text(tabContainer.children("ul").find('li.active').text());
                        tabItem.css('width', '100%');
                        tabItem.css('border-bottom', '1px solid #ccc');
                        tabItem.children("a").css('display', 'block');
                        tabItem.closest("ul").hide();
                    }
                };
            if (settings.visibleTabIndex) {
                var tabindex = parseInt(settings.visibleTabIndex, 10) - 1;
                tabItem.removeClass('active');
                $(this).children("ul").children("li").eq(tabindex).addClass("active");
                tabContent.children(".tab-pane").removeClass("active");
                tabContent.children(".tab-pane").eq(tabindex).addClass("active");
            }
            if (settings.breakpoint) {
                tabReset();
                $(window).resize(function () {
                    tabReset();
                });
            }
            if (settings.toggleTabMenu) {
            	var i = 0;
                $(settings.toggleTabMenu).on('click', function (event) {
                	
                	event.stopPropagation();
                	if(i === 0){
                    
                		tabItem.closest("ul").slideToggle(400,'swing', function(){i = 0; });
                    
                	}
                	i++;
                });
            }
            tabItem.on('click', function () {
                var tabIndex = $(this).index();
                tabItem.removeClass('active');
                $(this).addClass('active');
                tabContent.children('.tab-pane').removeClass('active').hide();
                $(this).closest(tabContainer).find(".tab-pane").eq(tabIndex).addClass('active').show();
                if ($(window).width() < parseInt(settings.breakpoint, 10)) {
                	$(settings.toggleTabMenu).text($(this).text());
                	$(this).closest("ul").slideUp();
                }
                
                
            });

        });
    };

}(jQuery));