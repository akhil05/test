var myApp = angular.module('formapp', []).controller('frmCtrl',
		function($scope) {
			$scope.user = {};
			$scope.save = function() {
				if ($scope.myForm.$valid) {
					alert(JSON.stringify($scope.user));
				}
			};
		});
